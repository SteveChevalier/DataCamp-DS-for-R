CREATE TABLE presidents (
  country                 VARCHAR   PRIMARY KEY,
  continent               VARCHAR,
  president               VARCHAR
);

CREATE TABLE prime_ministers (
  country                 VARCHAR   PRIMARY KEY,
  continent               VARCHAR,
  prime_minister          VARCHAR
);

CREATE TABLE states (
  name                    VARCHAR   PRIMARY KEY,
  continent               VARCHAR,
  indep_year              INTEGER,
  fert_rate               REAL,
  women_parli_perc        REAL
  
);

CREATE TABLE monarchs (
  country                 VARCHAR   PRIMARY KEY,
  continent               VARCHAR,
  monarch                 VARCHAR
);

-- Copy over data from CSVs note; this didn't work, there is more i need to know about it
\copy presidents FROM 'E:/One Drive/OneDrive/data_mining/DataCamp examples/22_countries2/presidents.csv' DELIMITER ',' CSV HEADER;
\copy prime_ministers FROM 'E:/One Drive/OneDrive/data_mining/DataCamp examples/22_countries2/prime_ministers.csv' DELIMITER ',' CSV HEADER;
\copy states FROM 'E:/One Drive/OneDrive/data_mining/DataCamp examples/22_countries2/states.csv' DELIMITER ',' CSV HEADER;
\copy monarchs FROM 'E:/One Drive/OneDrive/data_mining/DataCamp examples/22_countries2/monarchs.csv' DELIMITER ',' CSV HEADER;

/*
createdb leaders
psql leaders < data/leaders/leaders.sql
*/